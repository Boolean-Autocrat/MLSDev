<?php


global $lang;
$lang = array();

include_once dirname(__FILE__).'/versions/en-default.inc.php';

include_once dirname(__FILE__).'/custom/custom.inc.php';