/*---------------------------------------------------------
  Configuration
---------------------------------------------------------*/

// Set this to the server side language you wish to use.
var lang = 'php'; // options: lasso, php, py

// Set this to the directory you wish to manage.
//var fileRoot = '/UserFiles/'; //Set By Open-Realty

// Show image previews in grid views?
var showThumbs = true;
